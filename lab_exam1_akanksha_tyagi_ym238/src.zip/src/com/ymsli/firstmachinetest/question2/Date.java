package com.ymsli.firstmachinetest.question2;

public class Date {

}
